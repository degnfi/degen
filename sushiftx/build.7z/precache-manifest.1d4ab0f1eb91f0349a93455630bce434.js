self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fc3ec7ecd594cf65bfba2e28f9ddbd15",
    "url": "/index.html"
  },
  {
    "revision": "1644c87615a0e866a4b1",
    "url": "/static/css/main.389c87aa.chunk.css"
  },
  {
    "revision": "76569cca807213f35f4b",
    "url": "/static/js/0.878cf87f.chunk.js"
  },
  {
    "revision": "7da164cb84b4d2d87a51",
    "url": "/static/js/10.f83647f0.chunk.js"
  },
  {
    "revision": "3ca4e24fb2ec65b84915",
    "url": "/static/js/11.b71cce41.chunk.js"
  },
  {
    "revision": "e5bb8f4b4bbd32469c7d",
    "url": "/static/js/3.37c74c26.chunk.js"
  },
  {
    "revision": "15723851b11509ef1b9a8dbd2a0ef589",
    "url": "/static/js/3.37c74c26.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e79c541caf3275cd7d29",
    "url": "/static/js/4.f82cb9e1.chunk.js"
  },
  {
    "revision": "f0c453115d00500685f6",
    "url": "/static/js/5.41ddbe36.chunk.js"
  },
  {
    "revision": "374658371e5d9c95e00ea15067d24dad",
    "url": "/static/js/5.41ddbe36.chunk.js.LICENSE.txt"
  },
  {
    "revision": "eb9bb7da62c418bf68b6",
    "url": "/static/js/6.b5f3d4da.chunk.js"
  },
  {
    "revision": "88e5053053539c8b4a53480943cb0e08",
    "url": "/static/js/6.b5f3d4da.chunk.js.LICENSE.txt"
  },
  {
    "revision": "12fe89982d6f378754ea",
    "url": "/static/js/7.4233ce1c.chunk.js"
  },
  {
    "revision": "7ec01595672f75e83fd81b41f132f4c1",
    "url": "/static/js/7.4233ce1c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e2855b3d2b5e020d1b1b",
    "url": "/static/js/8.ba1540cf.chunk.js"
  },
  {
    "revision": "d43bcb65c23262ca7bd991f5625a0c00",
    "url": "/static/js/8.ba1540cf.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d02aa5eb3d43ac16b6d6",
    "url": "/static/js/9.aacf9d5f.chunk.js"
  },
  {
    "revision": "1644c87615a0e866a4b1",
    "url": "/static/js/main.3a2ebf28.chunk.js"
  },
  {
    "revision": "e13aec183fd83902e273",
    "url": "/static/js/runtime-main.2dea8294.js"
  },
  {
    "revision": "340da4748604e88a521163cda96d0d62",
    "url": "/static/media/chef.340da474.png"
  },
  {
    "revision": "c06f3a3e804ebc7343949fdca3fdd7f8",
    "url": "/static/media/metamask-fox.c06f3a3e.svg"
  },
  {
    "revision": "37f2bc6ecee2eb29b3cf6799ce58bf58",
    "url": "/static/media/wallet-connect.37f2bc6e.svg"
  }
]);